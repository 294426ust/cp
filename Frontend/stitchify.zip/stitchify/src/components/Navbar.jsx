import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow px-4 py-3 fixed top-0 left-0 w-full z-10">
      {/* Main Navbar Container */}
      <div className="flex justify-between items-center">
        {/* Logo / Brand */}
        <Link to="/" className="text-xl font-bold text-gray-800">
          Stitchify
        </Link>

        {/* Desktop Menu */}
        <div className="hidden sm:flex items-center space-x-6">
          <input
            type="text"
            placeholder="Search..."
            className="px-2 py-1 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Link to="/men" className="text-gray-700 hover:text-blue-600 text-sm">Men</Link>
          <Link to="/women" className="text-gray-700 hover:text-blue-600 text-sm">Women</Link>
          <Link to="/kids" className="text-gray-700 hover:text-blue-600 text-sm">Kids</Link>
          <Link to="/custom" className="text-gray-700 hover:text-blue-600 text-sm">Build from Scratch</Link>
          <Link to="/cart" className="text-gray-700 hover:text-blue-600 text-sm">Cart</Link>
          <Link to="/login" className="text-gray-700 hover:text-blue-600 text-sm">Login</Link>
        </div>

        {/* Hamburger (Mobile Only) */}
        <button
          className="sm:hidden text-gray-700 focus:outline-none"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            {menuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="flex flex-col items-center mt-3 space-y-3 sm:hidden">
          <input
            type="text"
            placeholder="Search..."
            className="px-3 py-1 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Link to="/men" className="text-gray-700 hover:text-blue-600 text-sm">Men</Link>
          <Link to="/women" className="text-gray-700 hover:text-blue-600 text-sm">Women</Link>
          <Link to="/kids" className="text-gray-700 hover:text-blue-600 text-sm">Kids</Link>
          <Link to="/custom" className="text-gray-700 hover:text-blue-600 text-sm">Build from Scratch</Link>
          <Link to="/cart" className="text-gray-700 hover:text-blue-600 text-sm">Cart</Link>
          <Link to="/login" className="text-gray-700 hover:text-blue-600 text-sm">Login</Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
