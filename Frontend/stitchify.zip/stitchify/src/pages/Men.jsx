// src/pages/Men.jsx
import React from 'react';

const Men = () => {
  return (
    <div className="text-center py-10">
      <h1 className="text-3xl font-bold">Men's Section</h1>
      <p>Here you can browse men's fashion!</p>
    </div>
  );
};

export default Men;
