// src/pages/Women.jsx
import React from 'react';

const Women = () => {
  return (
    <div className="text-center py-10">
      <h1 className="text-3xl font-bold">Women's Section</h1>
      <p>Here you can browse women's fashion!</p>
    </div>
  );
};

export default Women;
