// src/pages/Kids.jsx
import React from 'react';

const Kids = () => {
  return (
    <div className="text-center py-10">
      <h1 className="text-3xl font-bold">Kids Section</h1>
      <p>Here you can browse kids fashion!</p>
    </div>
  );
};

export default Kids;
