// src/pages/Custom.jsx
import React from 'react';

const Custom = () => {
  return (
    <div className="text-center py-10">
      <h1 className="text-3xl font-bold">Build From Scratch Section</h1>
      <p>Here you can make your own fashion!</p>
    </div>
  );
};

export default Custom;
