import React from 'react';

const Contact = () => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-6 text-center">Contact Information</h1>
      <p className="text-gray-700 text-center mb-8">
        For queries & assistance, feel free to reach out to us:
      </p>

      <div className="space-y-6 text-center text-gray-600">
        <div>
          <h2 className="font-semibold">Mail</h2>
          <p>support@stitchify.in</p>
        </div>

        <div>
          <h2 className="font-semibold">Phone</h2>
          <p>+91 9111553117 (12:00pm to 8:00pm)</p>
        </div>

        <div>
          <h2 className="font-semibold">Address</h2>
          <p>
            5th Floor, Srajan College of Design, <br />
            Bhugaon Road, Bavdhan, Pune 411021
          </p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
