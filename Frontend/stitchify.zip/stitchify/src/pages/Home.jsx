import React from 'react';

const Home = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center text-center px-4">
      <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
        Welcome to Stitchify
      </h1>
      <p className="text-lg md:text-xl text-gray-600 max-w-xl mb-8">
        Your one-stop destination for ready-made fashion and fully custom clothing — tailored to fit you perfectly.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <a
          href="/boutique"
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
        >
          Explore Boutique
        </a>
        <a
          href="/custom"
          className="px-6 py-3 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition"
        >
          Start Custom Order
        </a>
      </div>
    </div>
  );
};

export default Home;
