// menVideos.js (or inline inside MenMeasure.jsx)
export const menVideoData = [
    {
      category: 'Shirt',
      videos: [
        'https://www.youtube.com/watch?v=GgTywBYJd08',
        'https://www.youtube.com/watch?v=eIYs5H8beVs',
      ],
    },
    {
      category: 'Pant',
      videos: [
        'https://www.youtube.com/watch?v=R_oxPvcHOd4',
        'https://www.youtube.com/watch?v=DbP8RjFBSfU',
      ],
    },
    // Add more categories...
  ];
  